/*============================================================================
  File:     02_Variability.sql

  SQL Server Versions: 2016+, Azure SQL
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2020, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


/*
	Ensure using the latest compat mode
	Disable memory grant feedback
*/
USE [master]
GO
ALTER DATABASE [WideWorldImportersB] SET COMPATIBILITY_LEVEL = 150
GO

USE [WideWorldImportersB];
GO

ALTER DATABASE SCOPED CONFIGURATION SET ROW_MODE_MEMORY_GRANT_FEEDBACK = OFF;
GO

/*
	Create procedure that uses a date range
*/
DROP PROCEDURE IF EXISTS [Sales].[usp_OrderInfo_OrderDate];
GO

CREATE PROCEDURE [Sales].[usp_OrderInfo_OrderDate]
	@StartDate DATETIME,
	@EndDate DATETIME
AS
SELECT
	o.[CustomerID],
	o.[OrderDate],
	o.ExpectedDeliveryDate,
	o.[ContactPersonID],
	ol.StockItemID,
	ol.PickedQuantity
FROM [Sales].[Orders] o
JOIN [Sales].[OrderLines] ol
	ON [o].[OrderID] = [ol].[OrderID]
WHERE [OrderDate] >= @StartDate 
	AND [OrderDate] <= @EndDate
ORDER BY [OrderDate];
GO


/*
	Run each of these a few times and check the memory grant info
*/
DECLARE @StartDate DATETIME = '2016-01-01'
DECLARE @EndDate DATETIME = '2016-01-08'

EXEC [Sales].[usp_OrderInfo_OrderDate] @StartDate, @EndDate;
GO 5

DECLARE @StartDate DATETIME = '2016-01-01'
DECLARE @EndDate DATETIME = '2016-06-30'

EXEC [Sales].[usp_OrderInfo_OrderDate] @StartDate, @EndDate;
GO 5

DECLARE @StartDate DATETIME = '2016-01-01'
DECLARE @EndDate DATETIME = '2016-12-31'

EXEC [Sales].[usp_OrderInfo_OrderDate] @StartDate, @EndDate;
GO

/*
	Memory grant info in dm_exec_query_stats
*/
SELECT 
	t.text, 
	qs.query_plan_hash,
	qs.execution_count, 
	qs.min_grant_kb, 
	qs.min_ideal_grant_kb, 
	qs.max_ideal_grant_kb, 
	qs.max_grant_kb, 
	qs.total_grant_kb, 
	qs.total_ideal_grant_kb,
	qs.last_grant_kb, 
	qs.last_ideal_grant_kb, 
	qs.total_used_grant_kb, 
	qs.min_used_grant_kb, 
	qs.max_used_grant_kb,
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
ORDER BY qs.total_used_grant_kb DESC;
GO


/*
	Memory grant info in Query Store
	Memory grant info is reported as the number of 8 KB pages 
	for the query plan within the aggregation interval
*/
 SELECT
  	[qst].[query_sql_text],
  	[qsq].[query_id], 
  	[qsp].[plan_id],
  	[qsq].[object_id],
  	[rs].[count_executions],
  	[rs].[last_execution_time],
  	[rs].[avg_duration],
  	[rs].[avg_logical_io_reads],
  	[rs].[avg_query_max_used_memory] * 8 AS [AvgUsedKB],
  	[rs].[min_query_max_used_memory] * 8 AS [MinUsedKB], 
  	[rs].[max_query_max_used_memory] * 8 AS [MaxUsedKB],
  	[rs].[last_query_max_used_memory] * 8 AS [LastUsedKB],
  	[rs].[stdev_query_max_used_memory] * 8 AS [StDevUsedKB],
  	TRY_CONVERT(XML, [qsp].[query_plan]) AS [QueryPlan_XML]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id]
WHERE OBJECT_NAME([qsq].[object_id]) = 'usp_OrderInfo_OrderDate';
GO


/*
	Enable memory grant feedback
*/
ALTER DATABASE SCOPED CONFIGURATION SET ROW_MODE_MEMORY_GRANT_FEEDBACK = ON;
GO


/*
	Run again
*/
DECLARE @StartDate DATETIME = '2016-01-01'
DECLARE @EndDate DATETIME = '2016-01-08'

EXEC [Sales].[usp_OrderInfo_OrderDate] @StartDate, @EndDate;
GO 5

DECLARE @StartDate DATETIME = '2016-01-01'
DECLARE @EndDate DATETIME = '2016-06-30'

EXEC [Sales].[usp_OrderInfo_OrderDate] @StartDate, @EndDate;
GO 5

DECLARE @StartDate DATETIME = '2016-01-01'
DECLARE @EndDate DATETIME = '2016-12-31'

EXEC [Sales].[usp_OrderInfo_OrderDate] @StartDate, @EndDate;
GO 2


/*
	Memory grant info in dm_exec_query_stats
*/
SELECT 
	t.text, 
	qs.query_plan_hash,
	qs.execution_count, 
	qs.min_grant_kb, 
	qs.min_ideal_grant_kb, 
	qs.max_ideal_grant_kb, 
	qs.max_grant_kb, 
	qs.total_grant_kb, 
	qs.total_ideal_grant_kb,
	qs.last_grant_kb, 
	qs.last_ideal_grant_kb, 
	qs.total_used_grant_kb, 
	qs.min_used_grant_kb, 
	qs.max_used_grant_kb,
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
ORDER BY qs.total_used_grant_kb DESC;
GO


/*
	Memory grant info in Query Store
	Memory grant info is reported as the number of 8 KB pages for the query plan within the aggregation interval
*/
 SELECT
  	[qst].[query_sql_text],
  	[qsq].[query_id], 
  	[qsp].[plan_id],
  	[qsq].[object_id],
  	[rs].[count_executions],
  	[rs].[last_execution_time],
  	[rs].[avg_duration],
  	[rs].[avg_logical_io_reads],
  	[rs].[avg_query_max_used_memory] * 8 AS [AvgUsedKB],
  	[rs].[min_query_max_used_memory] * 8 AS [MinUsedKB], 
  	[rs].[max_query_max_used_memory] * 8 AS [MaxUsedKB],
  	[rs].[last_query_max_used_memory] * 8 AS [LastUsedKB],
  	[rs].[stdev_query_max_used_memory] * 8 AS [StDevUsedKB],
  	TRY_CONVERT(XML, [qsp].[query_plan]) AS [QueryPlan_XML]
  FROM [sys].[query_store_query] [qsq] 
  JOIN [sys].[query_store_query_text] [qst]
  	ON [qsq].[query_text_id] = [qst].[query_text_id]
  JOIN [sys].[query_store_plan] [qsp] 
  	ON [qsq].[query_id] = [qsp].[query_id]
  JOIN [sys].[query_store_runtime_stats] [rs] 
  	ON [qsp].[plan_id] = [rs].[plan_id]
  WHERE OBJECT_NAME([qsq].[object_id]) = 'usp_OrderInfo_OrderDate';
GO

/*
	A better way to find variability in the plan cache
*/
SELECT 
	t.text, 
	qs.query_plan_hash,
	qs.execution_count, 
	qs.min_grant_kb, 
	qs.min_ideal_grant_kb, 
	qs.max_ideal_grant_kb, 
	qs.max_grant_kb, 
	qs.total_grant_kb, 
	qs.total_ideal_grant_kb,
	qs.last_grant_kb, 
	qs.last_ideal_grant_kb, 
	qs.total_used_grant_kb, 
	qs.min_used_grant_kb, 
	qs.max_used_grant_kb,
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
WHERE (qs.max_used_grant_kb - qs.min_used_grant_kb) > 51200;
GO

SELECT 
	t.text, 
	qs.query_plan_hash,
	qs.execution_count, 
	qs.total_spills,
	qs.min_spills,
	qs.max_spills,
	qs.last_spills,
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
WHERE (qs.max_spills - qs.min_spills) > 1000;
GO


/*
	A better way to find variability in Query Store
*/
SELECT
	[qst].[query_sql_text],
	[qsq].[query_id], 
	[qsp].[plan_id],
	[qsq].[object_id],
	[rs].[count_executions],
	[rs].[last_execution_time],
	[rs].[avg_duration],
	[rs].[avg_logical_io_reads],
	[rs].[avg_query_max_used_memory] * 8 AS [AvgUsedKB],
	[rs].[min_query_max_used_memory] * 8 AS [MinUsedKB], 
	[rs].[max_query_max_used_memory] * 8 AS [MaxUsedKB],
	[rs].[last_query_max_used_memory] * 8 AS [LastUsedKB],
	[rs].[stdev_query_max_used_memory] * 8 AS [StDevUsedKB],
	TRY_CONVERT(XML, [qsp].[query_plan]) AS [QueryPlan_XML]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
ON [qsp].[plan_id] = [rs].[plan_id]
WHERE ([rs].[max_query_max_used_memory]*8) - ([rs].[min_query_max_used_memory]*8) > 51200; 
GO

SELECT
	[qst].[query_sql_text],
	[qsq].[query_id], 
	[qsp].[plan_id],
	[qsq].[object_id],
	[rs].[count_executions],
	[rs].[last_execution_time],
	[rs].[avg_duration],
	[rs].[avg_logical_io_reads],
	[rs].[avg_tempdb_space_used],
	[rs].[last_tempdb_space_used],
	[rs].[min_tempdb_space_used],
	[rs].[max_tempdb_space_used],
	[rs].[stdev_tempdb_space_used],
	TRY_CONVERT(XML, [qsp].[query_plan]) AS [QueryPlan_XML]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
ON [qsp].[plan_id] = [rs].[plan_id]
WHERE ([rs].[max_tempdb_space_used] - [rs].[min_tempdb_space_used]) > 1000; 
GO





/*
	Another example
*/

/*
	Check distribution of CustomerIDs
*/
USE [WideWorldImportersB];
GO

SELECT [CustomerID], COUNT([CustomerID])
FROM [WideWorldImportersB].[Sales].[CustomerTransactions]
GROUP BY [CustomerID]
ORDER BY COUNT([CustomerID]) DESC;
GO

/*
	Generate CustomerID list for SP to use
*/	
DROP TABLE IF EXISTS [WideWorldImportersB].[dbo].[CustomerIDs];
GO

SELECT 
	DISTINCT [CustomerID], 
	DENSE_RANK() OVER (ORDER BY [CustomerID]) AS RowNum
INTO [WideWorldImportersB].[dbo].[CustomerIDs]
FROM [WideWorldImportersB].[Sales].[CustomerTransactions];
GO

DELETE FROM [WideWorldImportersB].[dbo].[CustomerIDs]
WHERE [CustomerID] IN (1, 401);
GO

/*
	Create SP
*/
USE [WideWorldImportersB];
GO

DROP PROCEDURE IF EXISTS [Sales].[usp_CustomerTransactionInfo];
GO

CREATE PROCEDURE [Sales].[usp_CustomerTransactionInfo]
	@CustomerID INT
AS	

	SELECT [CustomerID], SUM([AmountExcludingTax])
	FROM [Sales].[CustomerTransactions]
	WHERE [CustomerID] = @CustomerID
	GROUP BY [CustomerID];
GO

/*
	Run external queries
*/

/*
	Get a baseline for query perf
*/
SELECT 
	t.text, 
	qs.execution_count, 
	qs.min_logical_reads, 
	qs.max_logical_reads, 
	qs.min_elapsed_time, 
	qs.max_elapsed_time, 
	qs.min_worker_time, 
	qs.max_worker_time, 
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
WHERE t.text LIKE '%usp_CustomerTransactionInfo%';
GO

/*
	Variability for I/O
*/
SELECT 
	t.text, 
	qs.execution_count, 
	qs.min_logical_reads, 
	qs.max_logical_reads, 
	qs.min_elapsed_time, 
	qs.max_elapsed_time, 
	qs.min_worker_time, 
	qs.max_worker_time, 
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
WHERE (qs.max_logical_reads - qs.min_logical_reads) > 1000000;
GO


/*
	Variability for Duration
*/
SELECT 
	t.text, 
	qs.execution_count, 
	qs.min_logical_reads, 
	qs.max_logical_reads, 
	qs.min_elapsed_time, 
	qs.max_elapsed_time, 
	qs.min_worker_time, 
	qs.max_worker_time, 
	qp.query_plan
FROM sys.dm_exec_query_stats AS qs 
CROSS APPLY sys.dm_exec_query_plan(qs.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
WHERE (qs.max_elapsed_time - qs.min_elapsed_time) > 1000000;
GO


/*
	Variability in PLANS
	Queries executed in the last 2 hours with multiple plans
*/
SELECT
	[qsq].[query_id], 
	COUNT([qsp].[plan_id]) AS [PlanCount],
	OBJECT_NAME([qsq].[object_id]) [ObjectName], 
	MAX(DATEADD(MINUTE, -(DATEDIFF(MINUTE, GETDATE(), GETUTCDATE())), 
		[qsp].[last_execution_time])) AS [LocalLastExecutionTime],
	MAX([qst].query_sql_text) AS [Query_Text]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
WHERE [qsp].[last_execution_time] > DATEADD(HOUR, -2, GETUTCDATE())
GROUP BY [qsq].[query_id], [qsq].[object_id]
HAVING COUNT([qsp].[plan_id]) > 1;
GO