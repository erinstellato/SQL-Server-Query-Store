/*============================================================================
  File:     01_FrequentQueries.sql

  SQL Server Versions: 2016+, Azure SQL
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2020, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Restore backup
*/
USE [master];
GO
RESTORE DATABASE [WideWorldImportersB] 
	FROM  DISK = N'C:\Backups\WWI_Standard.bak' 
		WITH  FILE = 1,  
	MOVE N'WWI_Primary' 
		TO N'C:\Databases\WideWorldImportersLarge\WideWorldImporters.mdf',  
	MOVE N'WWI_UserData' 
		TO N'C:\Databases\WideWorldImportersLarge\WideWorldImporters_UserData.ndf',  
	MOVE N'WWI_Log' 
		TO N'C:\Databases\WideWorldImportersLarge\WideWorldImporters.ldf',  
	NOUNLOAD,  
	REPLACE,  
	STATS = 5;
GO

/*
	Enable Query Store and clear anything that may be in there
*/
ALTER DATABASE [WideWorldImportersB] SET QUERY_STORE = ON;
GO

ALTER DATABASE [WideWorldImportersB] SET QUERY_STORE (
	OPERATION_MODE = READ_WRITE, 
	INTERVAL_LENGTH_MINUTES = 10
	);
GO

ALTER DATABASE [WideWorldImportersB] SET QUERY_STORE CLEAR;
GO


/*
	Create SP and Ad Hoc procedures
	Clear the plan cache
	Run SP workload
*/
DBCC FREEPROCCACHE;
GO



/*
	How many different queries if we look at query_hash?  
*/
SELECT COUNT(query_hash) AS CountQueries
FROM sys.dm_exec_query_stats;
GO

/*
	How many unique queries?
*/
SELECT COUNT (DISTINCT query_hash) AS CountUniqueQueries
FROM sys.dm_exec_query_stats;
GO

SELECT query_hash, COUNT (query_hash) AS CountUniqueQueries
FROM sys.dm_exec_query_stats
GROUP BY query_hash;
GO

/*
	How many different plans if we look at query_plan_hash?
*/
SELECT COUNT (query_plan_hash) AS CountPlans
FROM sys.dm_exec_query_stats;
GO

/*
	How many unique query plans?
*/
SELECT COUNT (DISTINCT query_plan_hash) AS CountUniquePlans
FROM sys.dm_exec_query_stats;
GO



-/*
	Using the DMVs to find high frequency - OPTION 1
	https://glennsqlperformance.com/resources/   
*/
-- Get most frequently executed queries for this database (Query 56) (Query Execution Counts)
SELECT TOP(50) LEFT(t.[text], 50) AS [Short Query Text], qs.execution_count AS [Execution Count], qs.query_plan_hash,
qs.total_logical_reads AS [Total Logical Reads],
qs.total_logical_reads/qs.execution_count AS [Avg Logical Reads],
qs.total_worker_time AS [Total Worker Time],
qs.total_worker_time/qs.execution_count AS [Avg Worker Time], 
qs.total_elapsed_time AS [Total Elapsed Time],
qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
CASE WHEN CONVERT(nvarchar(max), qp.query_plan) COLLATE Latin1_General_BIN2 LIKE N'%<MissingIndexes>%' THEN 1 ELSE 0 END AS [Has Missing Index],
qs.creation_time AS [Creation Time]
--,t.[text] AS [Complete Query Text], qp.query_plan AS [Query Plan] -- uncomment out these columns if not copying results to Excel
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t 
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp 
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);


/*
	Using the DMVs to find high frequency - OPTION 2
	https://sqlperformance.com/2019/10/t-sql-queries/death-by-a-thousand-cuts
*/
;WITH qh AS
(
    SELECT TOP (25) query_hash, COUNT(*) AS COUNT
    FROM sys.dm_exec_query_stats
    GROUP BY query_hash
    ORDER BY COUNT(*) DESC
),
qs AS
(
    SELECT 
		obj = COALESCE(ps.object_id,   fs.object_id,   ts.object_id), 
		db = COALESCE(ps.database_id, fs.database_id, ts.database_id),  
		qs.query_hash, 
		qs.query_plan_hash, 
		qs.execution_count,  
		qs.sql_handle, 
		qs.plan_handle
    FROM sys.dm_exec_query_stats AS qs
    INNER JOIN qh ON qs.query_hash = qh.query_hash
    LEFT OUTER JOIN sys.dm_exec_procedure_stats AS [ps] ON [qs].[sql_handle] = [ps].[sql_handle]
    LEFT OUTER JOIN sys.dm_exec_function_stats AS [fs] ON [qs].[sql_handle] = [fs].[sql_handle]
    LEFT OUTER JOIN sys.dm_exec_trigger_stats AS [ts] ON [qs].[sql_handle] = [ts].[sql_handle]
)
SELECT TOP (50)
  OBJECT_NAME(qs.obj, qs.db), 
  query_hash, 
  query_plan_hash, 
  SUM([qs].[execution_count]) AS [ExecutionCount], 
  MAX([st].[text]) AS [QueryText]
  FROM qs 
  CROSS APPLY sys.dm_exec_sql_text ([qs].[sql_handle]) AS [st]
  CROSS APPLY sys.dm_exec_query_plan ([qs].[plan_handle]) AS [qp]
  GROUP BY qs.obj, qs.db, qs.query_hash, qs.query_plan_hash
  ORDER BY ExecutionCount DESC;




/*
	Now run 6_AdHoc_multiple_clients and re-visit above queries
*/

/*
	We get better data from Query Store
*/
USE [WideWorldImportersB];
GO

SELECT COUNT(query_text_id) AS CountQueryText                                 
FROM sys.query_store_query_text;
GO


SELECT COUNT(query_id) AS CountQueries                                     
FROM sys.query_store_query; 
GO


SELECT COUNT(DISTINCT query_hash) AS CountUniqueQueries           
FROM sys.query_store_query; 
GO


SELECT COUNT(plan_id) AS CountPlanRows                                      
FROM sys.query_store_plan; 
GO


SELECT COUNT(DISTINCT query_plan_hash) AS CountUniquePlans 	     
FROM sys.query_store_plan; 
GO




/*
	Using Query Store to find high frequency - Option 1
	note that you can change the timestamps for rs.last_execution_time
	to look further in the past
*/
SELECT 
	TOP 10 SUM([rs].[count_executions]) [TotalExecutions],
	[qsq].[query_id],  
	[qst].[query_sql_text], 
	CASE
		WHEN [qsq].[object_id] = 0 THEN N'Ad-hoc'
		ELSE OBJECT_NAME([qsq].[object_id]) 
	END AS [ObjectName],
	[qsp].[plan_id], 
	TRY_CONVERT(XML, [qsp].[query_plan]) [QueryPlan]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id] 
WHERE [rs].[last_execution_time] > DATEADD(HOUR, -1, GETUTCDATE())  
AND [rs].[execution_type] = 0
GROUP BY [qsq].[query_id], [qst].[query_sql_text], [qsq].[object_id], [qsp].[plan_id], [qsp].[query_plan]
ORDER BY SUM([rs].[count_executions]) DESC;  
GO



/*
	Using Query Store to find high frequency - Option 2
	this query is not restricted, may take a while to run
*/
;WITH qh AS
(
SELECT TOP (25) query_hash, COUNT(*) AS COUNT
FROM sys.query_store_query
GROUP BY query_hash
ORDER BY COUNT(*) DESC
)
SELECT 
	OBJECT_NAME(q.object_id) AS [ObjectName],
	q.query_hash,
	p.query_plan_hash,
	SUM(rs.count_executions) AS [Execution_Count],
	MAX(t.query_sql_text)
FROM sys.query_store_query q
INNER JOIN qh	
	ON q.query_hash = qh.query_hash
INNER JOIN sys.query_store_plan p
	ON q.query_id = p.query_id
INNER JOIN sys.query_store_runtime_stats rs
	ON p.plan_id = rs.plan_id
INNER JOIN sys.query_store_query_text t
	ON q.query_text_id = t.query_text_id
GROUP BY OBJECT_NAME(q.object_id), q.query_hash, p.query_plan_hash