/*============================================================================
  File:     FindHighFrequency.sql

  SQL Server Versions: 2016+
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2020, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============
================================================================*/

/*
	Using the DMVs to find high frequency - OPTION 1
	https://glennsqlperformance.com/resources/   
*/
-- Get most frequently executed queries for this database (Query 56) (Query Execution Counts)
SELECT TOP(50) LEFT(t.[text], 50) AS [Short Query Text], qs.execution_count AS [Execution Count],
qs.total_logical_reads AS [Total Logical Reads],
qs.total_logical_reads/qs.execution_count AS [Avg Logical Reads],
qs.total_worker_time AS [Total Worker Time],
qs.total_worker_time/qs.execution_count AS [Avg Worker Time], 
qs.total_elapsed_time AS [Total Elapsed Time],
qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
CASE WHEN CONVERT(nvarchar(max), qp.query_plan) COLLATE Latin1_General_BIN2 LIKE N'%<MissingIndexes>%' THEN 1 ELSE 0 END AS [Has Missing Index],
qs.creation_time AS [Creation Time]
--,t.[text] AS [Complete Query Text], qp.query_plan AS [Query Plan] -- uncomment out these columns if not copying results to Excel
FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t 
CROSS APPLY sys.dm_exec_query_plan(plan_handle) AS qp 
ORDER BY qs.execution_count DESC OPTION (RECOMPILE);


/*
	Using the DMVs to find high frequency - OPTION 2
	https://sqlperformance.com/2019/10/t-sql-queries/death-by-a-thousand-cuts
*/
;WITH qh AS
(
    SELECT TOP (25) query_hash, COUNT(*) AS COUNT
    FROM sys.dm_exec_query_stats
    GROUP BY query_hash
    ORDER BY COUNT(*) DESC
),
qs AS
(
    SELECT 
		obj = COALESCE(ps.object_id,   fs.object_id,   ts.object_id), 
		db = COALESCE(ps.database_id, fs.database_id, ts.database_id),  
		qs.query_hash, 
		qs.query_plan_hash, 
		qs.execution_count,  
		qs.sql_handle, 
		qs.plan_handle
    FROM sys.dm_exec_query_stats AS qs
    INNER JOIN qh ON qs.query_hash = qh.query_hash
    LEFT OUTER JOIN sys.dm_exec_procedure_stats AS [ps] ON [qs].[sql_handle] = [ps].[sql_handle]
    LEFT OUTER JOIN sys.dm_exec_function_stats AS [fs] ON [qs].[sql_handle] = [fs].[sql_handle]
    LEFT OUTER JOIN sys.dm_exec_trigger_stats AS [ts] ON [qs].[sql_handle] = [ts].[sql_handle]
)
SELECT TOP (50)
  OBJECT_NAME(qs.obj, qs.db), 
  query_hash, 
  query_plan_hash, 
  SUM([qs].[execution_count]) AS [ExecutionCount], 
  MAX([st].[text]) AS [QueryText]
  FROM qs 
  CROSS APPLY sys.dm_exec_sql_text ([qs].[sql_handle]) AS [st]
  CROSS APPLY sys.dm_exec_query_plan ([qs].[plan_handle]) AS [qp]
  GROUP BY qs.obj, qs.db, qs.query_hash, qs.query_plan_hash
  ORDER BY ExecutionCount DESC;


/*
	Using Extended Events to find high frequency
	This is an expensive XE session (no filter), run for a VERY short amount of time
*/
CREATE EVENT SESSION [HighFrequency] ON SERVER 
ADD EVENT sqlserver.sp_statement_completed(
    ACTION(sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed)),
ADD EVENT sqlserver.sql_statement_completed(
    ACTION(sqlserver.query_hash_signed,sqlserver.query_plan_hash_signed))
ADD TARGET package0.event_file(SET filename=N'HighFrequency',max_file_size=(128))
WITH (MAX_MEMORY=16384 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,
TRACK_CAUSALITY=ON,STARTUP_STATE=OFF)
GO



/*
	Using Query Store to find high frequency - Option 1
	note that you can change the timestamps for rs.last_execution_time
	to look further in the past
*/
SELECT 
	TOP 10 SUM([rs].[count_executions]) [TotalExecutions],
	[qsq].[query_id],  
	[qst].[query_sql_text], 
	CASE
		WHEN [qsq].[object_id] = 0 THEN N'Ad-hoc'
		ELSE OBJECT_NAME([qsq].[object_id]) 
	END AS [ObjectName],
	[qsp].[plan_id], 
	TRY_CONVERT(XML, [qsp].[query_plan]) [QueryPlan]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id] 
WHERE [rs].[last_execution_time] > DATEADD(HOUR, -1, GETUTCDATE())  
AND [rs].[execution_type] = 0
GROUP BY [qsq].[query_id], [qst].[query_sql_text], [qsq].[object_id], [qsp].[plan_id], [qsp].[query_plan]
ORDER BY SUM([rs].[count_executions]) DESC;  
GO



/*
	Using Query Store to find high frequency - Option 2
	this query is not restricted, may take a while to run
*/
;WITH qh AS
(
SELECT TOP (25) query_hash, COUNT(*) AS COUNT
FROM sys.query_store_query
GROUP BY query_hash
ORDER BY COUNT(*) DESC
)
SELECT 
	OBJECT_NAME(q.object_id) AS [ObjectName],
	q.query_hash,
	p.query_plan_hash,
	SUM(rs.count_executions) AS [Execution_Count],
	MAX(t.query_sql_text)
FROM sys.query_store_query q
INNER JOIN qh	
	ON q.query_hash = qh.query_hash
INNER JOIN sys.query_store_plan p
	ON q.query_id = p.query_id
INNER JOIN sys.query_store_runtime_stats rs
	ON p.plan_id = rs.plan_id
INNER JOIN sys.query_store_query_text t
	ON q.query_text_id = t.query_text_id
GROUP BY OBJECT_NAME(q.object_id), q.query_hash, p.query_plan_hash