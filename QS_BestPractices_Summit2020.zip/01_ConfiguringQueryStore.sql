/*============================================================================
  File:     02_ConfiguringQueryStore.sql

  SQL Server Versions: 2016, 2017, 2019, Azure SQL DB
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2020, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Restore database
	*you may need to change the backup
	and restore locations
*/
USE [master]
GO

RESTORE DATABASE [WideWorldImporters] 
	FROM  DISK = N'C:\Backups\WideWorldImporters_Bits.bak' WITH  FILE = 1,  
	MOVE N'WWI_Primary' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.mdf',  
	MOVE N'WWI_UserData' TO N'C:\Databases\WideWorldImporters\WideWorldImporters_UserData.ndf',  
	MOVE N'WWI_Log' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.ldf',  
	NOUNLOAD,  REPLACE,  STATS = 5

GO

/*
	Enable Query Store through the UI
*/




/*
	this is the default if you script it out
*/
USE [master];
GO
ALTER DATABASE [WideWorldImporters] 
	SET QUERY_STORE = ON;
GO
ALTER DATABASE [WideWorldImporters] 
	SET QUERY_STORE (OPERATION_MODE = READ_WRITE);
GO


/*
	This is what it's really setting
*/
USE [master];
GO
ALTER DATABASE [WideWorldImporters] 
	SET QUERY_STORE = ON;
GO
ALTER DATABASE [WideWorldImporters] 
	SET QUERY_STORE (
		OPERATION_MODE = READ_WRITE, 
		CLEANUP_POLICY = 
			(STALE_QUERY_THRESHOLD_DAYS = 30), 
		DATA_FLUSH_INTERVAL_SECONDS = 900,  
		INTERVAL_LENGTH_MINUTES = 60, 
		MAX_STORAGE_SIZE_MB = 1000, /* 100 in 2016, 2017 */
		QUERY_CAPTURE_MODE = AUTO, /* ALL in 2016, 2017 */
		SIZE_BASED_CLEANUP_MODE = AUTO, 
		MAX_PLANS_PER_QUERY = 200,
		WAIT_STATS_CAPTURE_MODE = ON);
GO


/*
	Recommended settings, parameterized workload
*/

USE [master];
GO
ALTER DATABASE [WideWorldImporters] SET QUERY_STORE (
	OPERATION_MODE = READ_WRITE,
		/*	
			READ_WRITE = data collection; READ_ONLY = no data collection 
		*/
	CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30),  
		/*	
			how long to retain data in the query store, default is 30
			<< the more data you keep, the more space you will need >>
		*/
	DATA_FLUSH_INTERVAL_SECONDS = 900,
		/*	
			how frequently QS data is written to disk, default is 900 (15 minutes)
			how much QS data could be lost if there's a hard server crash
			Microsoft recommends this value
		*/
	INTERVAL_LENGTH_MINUTES = 30,
		/*	
			interval across which QS data is aggregated, default is 60 minutes
			use a smaller value if you need finer granularity or less time to detect and mitigate issues
			<< this will affect the size of the data (lower value = more data) >>
			arbitrary values are not allowed, you must use one of the following: 
				1, 5, 10, 15, 30, 60, and 1440 minutes
		*/
	MAX_STORAGE_SIZE_MB = 2048,
		/*	
			size of the QS (when the max is hit, status changes to READ_ONLY), default is 1000MB
			what this "should" be depends on your workload and how much data you want to keep:
				STALE_QUERY_THRESHOLD_DAYS
				INTERVAL_LENGTH_MINUTES
				QUERY_CAPTURE_MODE
	
		*/
	QUERY_CAPTURE_MODE = AUTO,
		/* 
			are ALL queries captured, or only relevant ones? AUTO is default in 2019
			AUTO means that infrequent queries and those with insignificant compile and 
				execution duration are ignored
				the thresholds (execution count, compile and runtime duration) 
				are internally determined
			CUSTOM added in 2019, this provides additional options to configure
		*/
	SIZE_BASED_CLEANUP_MODE = AUTO,
		/* 
			Do you want QS to go into clean up mode as usage gets close to MAX_STORAGE_SIZE_MB? 
			default is AUTO
		*/
	MAX_PLANS_PER_QUERY = 200,
		/*
			max number of plans to store for a query
		*/
	WAIT_STATS_CAPTURE_MODE = ON);
		/*
			whether wait statistics are captured in QS
		*/
GO
