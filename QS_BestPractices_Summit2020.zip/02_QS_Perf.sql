/*============================================================================
  File:     02_QS_Perf.sql

  SQL Server Versions: 2016, 2017, 2019, Azure SQL DB
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2020, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/


/*
	Enable QS and clear data
	NOTE: These are *NOT* settings recommended for Production
*/

ALTER DATABASE [WideWorldImporters] SET QUERY_STORE = ON;
GO

ALTER DATABASE [WideWorldImporters] SET QUERY_STORE (
	OPERATION_MODE = READ_WRITE, 
	DATA_FLUSH_INTERVAL_SECONDS = 60, 
	INTERVAL_LENGTH_MINUTES = 30, 
	QUERY_CAPTURE_MODE = ALL
	);
GO

ALTER DATABASE [WideWorldImporters] SET QUERY_STORE CLEAR;
GO

/*
	Run 02a_AdHocforWorkload to create SP for adhoc queries
	Run 02b_SPforWorkload to create SP for parameterized queries
*/


/*
	Open up PerfMon
	Run 2_SP_multiple_clients to generate workload
*/

/*
	What's in QS?
*/
USE [WideWorldImporters];
GO

SELECT
	[qsq].[query_id], 
	[qsp].[plan_id],
	[qsq].[object_id],
	[qsq].[query_hash],
	[rs].[count_executions],
	[rs].[last_execution_time],
	[rs].[avg_duration],
	[rs].[avg_logical_io_reads],
	[qst].[query_sql_text],
	TRY_CONVERT(XML, [qsp].[query_plan]) AS [QueryPlan_XML]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id];
GO


/*
	Check QS counts
*/
USE [WideWorldImporters];
GO

SELECT COUNT(*) AS CountQueryText                                 
FROM sys.query_store_query_text;
GO

SELECT COUNT(*) AS CountQueries                                     
FROM sys.query_store_query; 
GO

SELECT COUNT(*) AS CountPlanRows                                      
FROM sys.query_store_plan; 
GO

/*
	take note of counts

*/


/*
	Check memory use
*/
SELECT 
	type, 
	sum(pages_kb) AS [MemoryUsed_KB],
	sum(pages_kb)/1024 AS [MemoryUsed_MB]
FROM sys.dm_os_memory_clerks
WHERE type like '%QDS%'
or type like '%QueryDiskStore%'
GROUP BY type
ORDER BY type;
GO


/*
	take note of memory use

*/

/*
	Clear out QS data
*/
ALTER DATABASE [WideWorldImporters] SET QUERY_STORE CLEAR;
GO

/*
	Run 5_AdHoc_multiple_clients to generate adhoc workload
*/


/*
	What's in QS now?
*/
USE [WideWorldImporters];
GO

SELECT
	[qsq].[query_id], 
	[qsp].[plan_id],
	[qsq].[object_id],
	[qsq].[query_hash],
	[rs].[count_executions],
	[rs].[last_execution_time],
	[rs].[avg_duration],
	[rs].[avg_logical_io_reads],
	[qst].[query_sql_text],
	TRY_CONVERT(XML, [qsp].[query_plan]) AS [QueryPlan_XML]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id];
GO


/*
	Check QS counts
*/
USE [WideWorldImporters];
GO

SELECT COUNT(*) AS CountQueryText                                 
FROM sys.query_store_query_text;
GO

SELECT COUNT(*) AS CountQueries                                     
FROM sys.query_store_query; 
GO

SELECT COUNT(*) AS CountPlanRows                                      
FROM sys.query_store_plan; 
GO


/*
	Check memory use
*/
SELECT 
	type, 
	sum(pages_kb) AS [MemoryUsed_KB],
	sum(pages_kb)/1024 AS [MemoryUsed_MB]
FROM sys.dm_os_memory_clerks
WHERE type like '%QDS%'
or type like '%QueryDiskStore%'
GROUP BY type
ORDER BY type;
GO


EXEC sp_query_store_flush_db;
GO

/*
	Run queries again, does memory use change?
*/
SELECT 
	type, 
	sum(pages_kb) AS [MemoryUsed_KB],
	sum(pages_kb)/1024 AS [MemoryUsed_MB]
FROM sys.dm_os_memory_clerks
WHERE type like '%QDS%'
or type like '%QueryDiskStore%'
GROUP BY type
ORDER BY type;
GO


/*
	take note of memory use

*/

/*
	Clear out QS again
	Open up PerfMon
*/
ALTER DATABASE [WideWorldImporters] SET QUERY_STORE CLEAR;
GO



/*
	Now, turn OFF Query Store and monitor PerfMon
*/
ALTER DATABASE [WideWorldImporters] SET QUERY_STORE = OFF;
GO

/*
	Run 2_SP_multiple_clients to generate workload
*/

/*
	Run 2_AdHoc_multiple_clients to generate adhoc workload
*/

