Scripts to recreate the demos are located in the Scripts Folder.

To generate the workload and regression for Automatic Plan Correction, use the files in the Workload folder.  Command line files will need to be edited to point to your instance (instead of WIN2016\SQL2017).

WideWorldImporters can be downloaded from github:https://github.com/Microsoft/sql-server-samples/tree/master/samples/databases/wide-world-importers