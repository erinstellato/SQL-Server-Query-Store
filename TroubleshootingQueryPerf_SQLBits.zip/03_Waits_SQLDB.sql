/*============================================================================
  File:     04_Waits_SQLDB.sql

  SQL Server Versions: Azure SQL DB
------------------------------------------------------------------------------
  Written by Erin Stellato
  
  (c) 2024, Erin Stellato. All rights reserved.

  For more scripts and sample code, see 
    https://github.com/erinstellato

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	kick off long-running query
*/

/*
	Run in another window
	note the session_id
*/
EXEC sp_whoisactive



IF EXISTS (
	SELECT * 
	FROM sys.server_event_sessions
	WHERE [name] = 'TrackWaits')
BEGIN
	DROP EVENT SESSION [TrackWaits] ON DATABASE;
END
GO

/*
	XE session to create (also run in another window)
	change predicate as needed
*/		
CREATE EVENT SESSION [TrackWaits] 
	ON DATABASE 
ADD EVENT sqlos.wait_completed(
    WHERE ([sqlserver].[session_id]=(57)) AND ([duration]>(0))
	)
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,
MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF);
GO	


/*
	Start session
*/
ALTER EVENT SESSION [TrackWaits] 
	ON DATABASE
	STATE = START;
GO

/*
	Jonathan's post on mapping wait types
	https://www.sqlskills.com/blogs/jonathan/mapping-wait-types-in-dm_os_wait_stats-to-extended-events/
*/


/*
	You can use the DMVs, but remember the wait stats are aggregate
*/
SELECT *
FROM sys.dm_exec_session_wait_stats
WHERE session_id = 57
ORDER BY waiting_tasks_count DESC;
GO


/*
	Stop session
*/
ALTER EVENT SESSION [TrackWaits] 
	ON DATABASE
	STATE = STOP;
GO

/*
	Clean up
*/
DROP EVENT SESSION [TrackWaits] 
	ON DATABASE;
GO