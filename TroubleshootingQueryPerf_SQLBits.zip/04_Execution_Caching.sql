/*============================================================================
  File:     04_Execution_Caching.sql

   SQL Server Versions: 2016+, MI, SQL DB
------------------------------------------------------------------------------
  Written by Erin Stellato
  
  (c) 2024, Erin Stellato. All rights reserved.

  For more scripts and sample code, see 
    https://github.com/erinstellato

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Restore database
	*you may need to change the backup
	and restore locations
*/
USE [master]
GO

RESTORE DATABASE [WideWorldImporters] 
	FROM  DISK = N'C:\Backups\WideWorldImporters_Bits.bak' WITH  FILE = 1,  
	MOVE N'WWI_Primary' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.mdf',  
	MOVE N'WWI_UserData' TO N'C:\Databases\WideWorldImporters\WideWorldImporters_UserData.ndf',  
	MOVE N'WWI_Log' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.ldf',  
	NOUNLOAD,  REPLACE,  STATS = 5

GO


/*
	Prep if needed
*/
INSERT INTO [Warehouse].[StockItems]
           ([StockItemID]
           ,[StockItemName]
           ,[SupplierID]
           ,[ColorID]
           ,[UnitPackageID]
           ,[OuterPackageID]
           ,[Brand]
           ,[Size]
           ,[LeadTimeDays]
           ,[QuantityPerOuter]
           ,[IsChillerStock]
           ,[Barcode]
           ,[TaxRate]
           ,[UnitPrice]
           ,[RecommendedRetailPrice]
           ,[TypicalWeightPerUnit]
           ,[MarketingComments]
           ,[InternalComments]
           ,[Photo]
           ,[CustomFields]
           ,[LastEditedBy]
           ,[ValidFrom]
           ,[ValidTo])
     VALUES
           (228
           ,'Chocolate toads 250g'
           ,1
           ,NULL
           ,1
           ,6
           ,''
           ,'250g'
           ,3
           ,24
           ,1
           ,'8792838293988'
           ,10.00
           ,7.55
           ,11.23
           ,0.250
           ,'Perfect for your child''s party'
           ,NULL
           ,NULL
           ,'{ "CountryOfManufacture": "USA", "ShelfLife": "7 days", "Tags": [] }'
           ,1
           ,'2019-01-01 23:00:00.0000000'
           ,'9999-12-31 23:59:59.9999999')
GO

UPDATE Sales.Orderlines 
	SET StockItemID = 228, 
	Description = 'Chocolate toads 250g', 
	UnitPrice = 7.55
WHERE OrderID < 70000

CREATE NONCLUSTERED INDEX NCI_OrderLines_Description
	ON Sales.OrderLines	(Description) INCLUDE (UnitPrice)


/*
	Create procedure to use to look at plan cache and query store
*/
USE [WideWorldImporters];
GO

DROP PROCEDURE IF EXISTS [dbo].[GetCacheQueryStoreInfo];
GO

CREATE PROCEDURE [dbo].[GetCacheQueryStoreInfo] @QueryString NVARCHAR(100)
AS
BEGIN

SELECT [st].[text], [qs].[execution_count], [qs].*, [p].* 
FROM sys.dm_exec_query_stats AS [qs] 
	CROSS APPLY sys.dm_exec_sql_text ([sql_handle]) [st]
	CROSS APPLY sys.dm_exec_query_plan ([plan_handle]) [p]
WHERE [st].[text] LIKE @QueryString
ORDER BY [st].[text];

SELECT 
	[qsq].[query_id],  
	[qst].[query_sql_text], 
	CASE
		WHEN [qsq].[object_id] = 0 THEN N'Ad-hoc'
		ELSE OBJECT_NAME([qsq].[object_id]) 
	END AS [ObjectName],
	[qsp].[plan_id], 
	[rs].[count_executions],
	[rs].[avg_logical_io_reads], 
	[rs].[avg_duration],
	TRY_CONVERT(XML, [qsp].[query_plan]),
	[rs].[last_execution_time],
	(DATEADD(MINUTE, -(DATEDIFF(MINUTE, GETDATE(), GETUTCDATE())), 
	[rs].[last_execution_time])) AS [LocalLastExecutionTime]
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id] 
WHERE [qst].[query_sql_text] LIKE @QueryString;

END

/*
	Clear out the plan cache
*/
DBCC FREEPROCCACHE;
GO


/*
	Run a few queries...are they simple?
*/
USE [WideWorldImporters];
GO

SELECT *
FROM Warehouse.StockItems
WHERE StockItemID = 7;
GO

SELECT *
FROM Warehouse.StockItems
WHERE StockItemID = 1385;
GO

SELECT *
FROM Warehouse.StockItems
WHERE StockItemID = 92984;
GO

/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%StockItemID%'

/*
	Run a few more queries, are these simple?
*/
SELECT *
FROM Warehouse.StockItems
WHERE StockItemName LIKE 'Chocolate%';
GO

SELECT *
FROM Warehouse.StockItems 
WHERE stockitemname LIKE 'Chocolate%';
GO

SELECT *
FROM Warehouse.StockItems
WHERE StockItemName LIKE '%animal%';
GO


/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%StockItemName%'


/*
	What happens if we use sp_executesql?
*/
DECLARE @SQLString NVARCHAR (4000);
SELECT @SQLString =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemID = @StockItemID';
EXEC sp_executesql @SQLString, N'@StockItemID INT', 7;
GO

DECLARE @SQLString NVARCHAR (4000);
SELECT @SQLString =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemID = @StockItemID';
EXEC sp_executesql @SQLString, N'@StockItemID INT', 1385;
GO

DECLARE @SQLString NVARCHAR (4000);
SELECT @SQLString =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemID = @StockItemID';
EXEC sp_executesql @SQLString, N'@StockItemID INT', 92984;
GO


/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%@StockItemID%'


/*
	What about sp_executesql when it's not simple?
*/
DECLARE @SQLString NVARCHAR (4000);
SELECT @SQLString =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemName LIKE @StockItemName';
EXEC sp_executesql @SQLString, N'@StockItemName VARCHAR(20)', 'Chocolate%';
GO

DECLARE @SQLString NVARCHAR (4000);
SELECT @SQLString =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemName LIKE @StockItemName';
EXEC sp_executesql @SQLString, N'@StockItemName VARCHAR(20)', '%animal%';
GO

DECLARE @SQLString NVARCHAR (4000);
SELECT @SQLString =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemName LIKE @StockItemName';
EXEC sp_executesql @SQLString, N'@StockItemName VARCHAR(20)', 'Superhero action jacket (Blue) M';
GO

/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%@StockItemName%'


/*
	What happens with DSE and a simple statement
*/

DECLARE @DSEstring NVARCHAR (4000);
DECLARE @StockItemID2 INT;
SET @StockItemID2 = 7
SELECT @DSEstring =
	N'SELECT si.*
	FROM Warehouse.StockItems si
	WHERE si.StockItemID = CONVERT (INT,' + CONVERT (NVARCHAR (10), @StockItemID2) + N')'
EXEC (@DSEstring);
GO

DECLARE @DSEstring NVARCHAR (4000);
DECLARE @StockItemID2 INT;
SET @StockItemID2 = 1385;
SELECT @DSEstring =
	N'SELECT si.*
	FROM Warehouse.StockItems si
	WHERE si.StockItemID = CONVERT (INT,' + CONVERT (NVARCHAR (10), @StockItemID2) + N')'
EXEC (@DSEstring);
GO

DECLARE @DSEstring NVARCHAR (4000);
DECLARE @StockItemID2 INT;
SET @StockItemID2 = 92984;
SELECT @DSEstring =
	N'SELECT si.*
	FROM Warehouse.StockItems si
	WHERE si.StockItemID = CONVERT (INT,' + CONVERT (NVARCHAR (10), @StockItemID2) + N')'
EXEC (@DSEstring);
GO

/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%CONVERT%'


/*
	DSE and a statement that's not simple
*/
DECLARE @DSEstring NVARCHAR (4000);
DECLARE @StockItemName2 VARCHAR(20);
SET @StockItemName2 = 'Chocolate%';
SELECT @DSEstring =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemName LIKE CONVERT (VARCHAR (20), ''' + REPLACE (@StockItemName2, '''', '''''') + N''')';
SELECT @DSEstring;
EXEC (@DSEstring);
GO

DECLARE @DSEstring NVARCHAR (4000);
DECLARE @StockItemName2 VARCHAR(20);
SET @StockItemName2 = '%animal%';
SELECT @DSEstring =
	N'SELECT *
	FROM Warehouse.StockItems
	WHERE StockItemName LIKE CONVERT (VARCHAR (20), ''' + REPLACE (@StockItemName2, '''', '''''') + N''')';
SELECT @DSEstring;
EXEC (@DSEstring);
GO


/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%StockItemName LIKE CONVERT%'


/*
	Create a couple stored procedures
*/
DROP PROCEDURE IF EXISTS [Warehouse].[usp_StockItemByID];
GO

CREATE PROCEDURE [Warehouse].[usp_StockItemByID] @StockItemID INT
AS
BEGIN
	SELECT [s].*
	FROM [Warehouse].[StockItems] [s]
	WHERE [s].[StockItemID] = @StockItemID

END
GO


DROP PROCEDURE IF EXISTS [Warehouse].[usp_StockItemByDesc];
GO

CREATE PROCEDURE [Warehouse].[usp_StockItemByDesc] @StockItemDesc NVARCHAR(100)
AS
BEGIN
	SELECT *
	FROM [Warehouse].[StockItems]
	WHERE [StockItemName] LIKE @StockItemDESC

END
GO


/*
	Execute both multiple times
*/
EXEC [Warehouse].[usp_StockItemByID] 7;
GO 5

EXEC [Warehouse].[usp_StockItemByID] 92984;
GO 5

EXEC [Warehouse].[usp_StockItemByDesc] 'Chocolate%';
GO 10

EXEC [Warehouse].[usp_StockItemByDesc] 'Superhero action jacket (Blue) M';
GO 10


/*
	Check plan cache and query store
*/
EXEC [dbo].[GetCacheQueryStoreInfo] N'%usp_StockItemByID%'
EXEC [dbo].[GetCacheQueryStoreInfo] N'%usp_StockItemByDesc%'



