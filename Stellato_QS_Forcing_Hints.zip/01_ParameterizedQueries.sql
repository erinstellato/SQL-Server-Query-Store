/*============================================================================
  File:     01_ParameterizedQueries.sql

  SQL Server Versions: 2016+, Azure SQL
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2021, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Start with a clean copy of WWI
*/
USE [master];
GO
RESTORE DATABASE [WideWorldImporters] 
FROM  DISK = N'C:\Backups\WideWorldImportersEnlarged.bak' 
WITH  FILE = 1,  
MOVE N'WWI_Primary' 
	TO N'C:\Databases\WideWorldImporters\WideWorldImporters.mdf',  
MOVE N'WWI_UserData' 
	TO N'C:\Databases\WideWorldImporters\WideWorldImporters_UserData.ndf',  
MOVE N'WWI_Log' 
	TO N'C:\Databases\WideWorldImporters\WideWorldImporters.ldf',  
MOVE N'WWI_InMemory_Data_1' 
	TO N'C:\Databases\WideWorldImporters\WideWorldImporters_InMemory_Data_1',  
NOUNLOAD, 
REPLACE, 
STATS = 5;
GO


/*
	Enable Query Store with settings we want
	(for next demo)
*/
USE [master];
GO

ALTER DATABASE [WideWorldImporters] 
	SET QUERY_STORE = ON;
GO

ALTER DATABASE [WideWorldImporters] SET QUERY_STORE (
	OPERATION_MODE = READ_WRITE, 
	CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), 
	DATA_FLUSH_INTERVAL_SECONDS = 60,  
	INTERVAL_LENGTH_MINUTES = 10, 
	MAX_STORAGE_SIZE_MB = 100, 
	QUERY_CAPTURE_MODE = ALL, 
	SIZE_BASED_CLEANUP_MODE = AUTO, 
	MAX_PLANS_PER_QUERY = 200)
GO

/*
	Clear out any old data, just in case
*/
ALTER DATABASE [WideWorldImporters] 
	SET QUERY_STORE CLEAR;
GO

/*
	Create procedure for testing
*/
DROP PROCEDURE IF EXISTS [Sales].[usp_CustomerTransactionInfo];
GO

CREATE PROCEDURE [Sales].[usp_CustomerTransactionInfo]
	@CustomerID INT
AS	

	SELECT [CustomerID], SUM([AmountExcludingTax])
	FROM [Sales].[CustomerTransactions]
	WHERE [CustomerID] = @CustomerID
	GROUP BY [CustomerID];
GO

/*
	Run the SP with a couple different Customer IDs
	enable actual plan
*/
SET STATISTICS IO, TIME ON;
GO

EXEC [Sales].[usp_CustomerTransactionInfo] 860;
GO

EXEC [Sales].[usp_CustomerTransactionInfo] 401;
GO

/*
	Clear cache
*/
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

/*
	Run with 401 again
*/
EXEC [Sales].[usp_CustomerTransactionInfo] 401;
GO


/*
	Check distribution
*/
SELECT [CustomerID], COUNT(*)
FROM [Sales].[CustomerTransactions]
GROUP BY [CustomerID]
ORDER BY COUNT(*) DESC;
GO

/*
	re-run and check plan for warnings/notifications
*/
EXEC [Sales].[usp_CustomerTransactionInfo] 401;
GO


/*
	There's a recommended index, but what if this is
	a third-party application, and you cannot
	change or add indexes?

	You could add the OPTIMIZE FOR hint to the query, but
	if it's a third-party application, you cannot
	change the code.

	Determine which plan is "better" 
	
	For a stored procedure, scalar UDF, MSTVF, and UDF, use an OBJECT plan guide
	For a stand-alone query, use a SQL or TEMPLATE plan guide 
*/
EXEC sp_create_plan_guide   
    @name =  N'CustomerTxnInfo_SP_PlanGuide1',  
    @stmt = N'SELECT [CustomerID], 
			SUM([AmountExcludingTax])
		FROM [Sales].[CustomerTransactions]
		WHERE [CustomerID] = @CustomerID
		GROUP BY [CustomerID];',  
    @type = N'OBJECT',  
    @module_or_batch = N'[Sales].[usp_CustomerTransactionInfo]',  
    @params = NULL,  
    @hints = N'OPTION (OPTIMIZE FOR (@CustomerID = 860))'; 

/*
	Re-run the stored procedure
*/	
EXEC [Sales].[usp_CustomerTransactionInfo] 860;
GO

EXEC [Sales].[usp_CustomerTransactionInfo] 401;
GO


/*
	Run it with another value...
	How do we know if a plan guide is being used?
*/
EXEC [Sales].[usp_CustomerTransactionInfo] 804;
GO

/*
	Check to see what plan guides exist
*/
SELECT *
FROM [sys].[plan_guides];
GO

/*
	Any issues with using the plan guide?
*/
SELECT *
FROM sys.fn_validate_plan_guide (65539);
GO

/*
	Remove ALL plan guides in a database
*/
EXEC sp_control_plan_guide N'DROP ALL';  
GO  


/*
	What do we see in Query Store UI
	for usp_CustomerTransactionInfo?
*/
SELECT
	[qsq].[query_id], 
	[qsp].[plan_id], 
	[qsq].[object_id], 
	[rs].[count_executions],
	DATEADD(MINUTE, -(DATEDIFF(MINUTE, GETDATE(), GETUTCDATE())), 
		[qsp].[last_execution_time]) AS [LocalLastExecutionTime],
	[qst].[query_sql_text], 
	ConvertedPlan = TRY_CONVERT(XML, [qsp].[query_plan])
FROM [sys].[query_store_query] [qsq] 
JOIN [sys].[query_store_query_text] [qst]
	ON [qsq].[query_text_id] = [qst].[query_text_id]
JOIN [sys].[query_store_plan] [qsp] 
	ON [qsq].[query_id] = [qsp].[query_id]
JOIN [sys].[query_store_runtime_stats] [rs] 
	ON [qsp].[plan_id] = [rs].[plan_id]
WHERE [qsq].[object_id] = OBJECT_ID(N'Sales.usp_CustomerTransactionInfo');
GO

/*
	Force the plan in QS, or with SP
	sp_query_store_force_plan (query_id, plan_id)
*/
EXEC sp_query_store_force_plan @query_id = 1, @plan_id = 1
GO

/*
	Re-run the stored procedures
*/	
EXEC [Sales].[usp_CustomerTransactionInfo] 401;
GO

EXEC [Sales].[usp_CustomerTransactionInfo] 860;
GO

/*
	How do we know if a forced plan is being used?
*/

/*
	What's in cache?
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
GO
SELECT 
	[qs].execution_count, 
	[s].[text], 
	[qs].[query_hash], 
	[qs].[query_plan_hash], 
	[cp].[size_in_bytes]/1024 AS [PlanSizeKB], 
	[qp].[query_plan], 
	[qs].[plan_handle]
FROM [sys].[dm_exec_query_stats] AS [qs]
CROSS APPLY [sys].[dm_exec_query_plan] ([qs].[plan_handle]) AS [qp]
CROSS APPLY [sys].[dm_exec_sql_text]([qs].[plan_handle]) AS [s]
INNER JOIN [sys].[dm_exec_cached_plans] AS [cp] 
	ON [qs].[plan_handle] = [cp].[plan_handle]
WHERE [s].[text] LIKE '%usp_CustomerTransactionInfo%';
GO
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
GO

/*
	Remove forcing
*/
EXEC sp_query_store_unforce_plan @query_id = 1, @plan_id = 1
GO


