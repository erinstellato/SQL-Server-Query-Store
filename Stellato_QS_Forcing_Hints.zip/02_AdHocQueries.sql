/*============================================================================
  File:     02_AdHocQueries.sql

  SQL Server Versions: 2016+, Azure SQL
------------------------------------------------------------------------------
  Written by Erin Stellato, SQLskills.com
  
  (c) 2021, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/*
	Clear cache 
*/
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE;
GO

/*
	What about an individual query?
	Run each query separately
	(turn on actual plan)
*/
SET STATISTICS IO ON;
GO

SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 860
GROUP BY [CustomerID];
GO

SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 401
GROUP BY [CustomerID];
GO

SET STATISTICS IO OFF;
GO

/*
	Find the plans in cache
*/
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
GO
SELECT 
	[qs].execution_count, 
	[s].[text], 
	[qs].[query_hash], 
	[qs].[query_plan_hash], 
	[qp].[query_plan], 
	[qs].[plan_handle]
FROM [sys].[dm_exec_query_stats] AS [qs]
CROSS APPLY [sys].[dm_exec_query_plan] ([qs].[plan_handle]) AS [qp]
CROSS APPLY [sys].[dm_exec_sql_text]([qs].[plan_handle]) AS [s]
WHERE [s].[text] LIKE '%CustomerTransactions%';
GO
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
GO


/*
	Remove the plan(s) from cache
*/
DBCC FREEPROCCACHE(
	0x060006006B480E08F05C5E5F7601000001000000000000000000000000000000000000000000000000000000

	);
GO
DBCC FREEPROCCACHE(
	0x0600060039B26F0A40602A777601000001000000000000000000000000000000000000000000000000000000
	);
GO

/*
	Create a SQL plan guide
*/

DECLARE @SQLStatement NVARCHAR(MAX);
DECLARE @Parameters NVARCHAR(MAX);
EXEC sp_get_query_template 
    N'SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 860
GROUP BY [CustomerID];',
	@SQLStatement OUTPUT,
	@Parameters OUTPUT
	  
EXEC sp_create_plan_guide   
    @name =  N'CustomerTxnInfo_Query_PlanGuide',  
	@stmt = @SQLStatement,
    @type = N'TEMPLATE',  
    @module_or_batch = NULL,  
    @params = @Parameters,  
    @hints = N'OPTION (PARAMETERIZATION FORCED)'; 

/*
	Re-run the queries 
*/
SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 860
GROUP BY [CustomerID];
GO

SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 401
GROUP BY [CustomerID];
GO

/*
	Change casing and spacing,
	what happens to the plan?
*/
SELECT 
	[CustomerID], 
	sum([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] =	401
GROUP BY [CustomerID];
GO

/*
	Check to see what plan guides exist
*/
SELECT *
FROM [sys].[plan_guides];
GO

/*
	Any issues with using the plan guide?
*/
SELECT *
FROM sys.fn_validate_plan_guide (65538);
GO

/*
	Remove ALL plan guides in a database
*/
EXEC sp_control_plan_guide N'DROP ALL';  
GO  

/*
	What do we see in Query Store?
*/

/*
	No way to force a plan for all variations of 
	this query because there are literal values.
	What about other query hints?
*/
/*
	OPTIMIZE FOR UNKNOWN
	This works, but I'm changing 
	the query syntax
*/
SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = 860
GROUP BY [CustomerID]
OPTION (OPTIMIZE FOR UNKNOWN);
GO

/*
	What about using variables?
	This works, but I'm changing the code
	(could be implemented as a variable
	with a forced plan, or with OPTIMIZE FOR)
*/
DECLARE @CustomerID INT;
SET @CustomerID = 401;

SELECT 
	[CustomerID], 
	SUM([AmountExcludingTax])
FROM [Sales].[CustomerTransactions]
WHERE [CustomerID] = @CustomerID
GROUP BY [CustomerID]
OPTION (OPTIMIZE FOR (@CustomerID = 860));
GO
